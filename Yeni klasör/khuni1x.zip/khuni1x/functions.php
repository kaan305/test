<?php

# Define Content Width
global $content_width;
if ( ! isset( $content_width ) ) {
	$content_width = 1140;
}

# Load the theme
if ( ! function_exists( "load_theme" ) ) {

	function load_theme() {
		require_once( get_template_directory() . '/inc/loader.php' );
		$smtheme = new SMThemeLoader();
		$smtheme->start( array( 'theme' => 'Khuni1x', 'slug' => 'khuni1x', 'version' => '1.0' ) );
	}

	load_theme();

}




function my_acf_load_value( $value, $post_id, $field )
{
    // run the_content filter on all textarea values
    $value = apply_filters('the_content',$value); 

    return $value;
}
add_filter('acf/load_value/name=page_builders', 'my_acf_load_value', 10, 3);


function add_menuclass($ulclass) {
	return preg_replace('/<a /', '<a class="smoth-scroll"', $ulclass);
}
add_filter('wp_nav_menu','add_menuclass');


//add_action( 'elementor/widgets/widgets_registered', 'remove_widgets' );
add_action( 'elementor/init', 'remove_widgets' );
add_action( 'elementor/loaded', 'remove_widgets' );
//add_action( 'widgets_init', 'remove_widgets' );
function remove_widgets(){
  
//    global $wp_widget_factory;
    
//    var_dump($wp_widget_factory);
    
//    $wp_widget_factory->widgets['SMT_Button_Widget_SO'] = null;
    
//    var_dump(Elementor\Plugin::instance()->widgets_manager->_widget_types);
    
//    echo "<script>$('div:contains(\'SMT Button\')').css('background-color','red');alert('asd');</script>";
//    echo "<script>(function ($) {'use strict';jQuery(document).ready(function () {alert(123);})(jQuery);</script>";
    
    
function myscript() {
?>
<script type="text/javascript">
(function ($) {
    'use strict';
    jQuery(window).load(function () {

        alert(1);
        
//        $("div:contains('SMT Button')").css("background-color","red");
        console.warn($("div"));
        console.warn($(".title"));
        $("div.title").css("background-color","red");

        alert(2);
        
    });
})(jQuery);
</script>
<?php
}
//add_action( 'wp_footer', 'myscript' );    
        
//    unregister_widget('WP_Widget_Pages');
//    unregister_widget('SMT_Button_Widget_SO');
}
