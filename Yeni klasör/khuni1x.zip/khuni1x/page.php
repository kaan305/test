<?php
get_header(); ?>
<?php if ( have_posts() ) : ?>
    <?php while ( have_posts() ) : the_post(); ?>
            <?php the_content(); ?>
	<?php endwhile; ?>
<?php else : ?>
    <p><?php _e( 'Sorry, no posts matched your criteria.', 'khuni1x' ); ?></p>
<?php endif; ?>
<div style="clear:both;float:none;"></div>
<?php get_footer(); ?>